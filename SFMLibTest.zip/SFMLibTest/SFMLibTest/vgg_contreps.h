#ifndef VGG_CONTREPS
#define VGG_CONTREPS

#include <cv.h>

CvMat* vgg_contreps(CvMat *X);

#endif