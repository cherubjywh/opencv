#ifndef VGG_X_FROM_XP_LIN
#define VGG_X_FROM_XP_LIN

#include <cv.h>

CvMat* vgg_X_from_xP_lin(CvMat *u, CvMat **P, int K, CvMat *imsize);

#endif